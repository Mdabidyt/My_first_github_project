/*let number =prompt("please givle a number")

number=Number.parseInt(number)
if (number>4){
        location.href="http://google.com"
}
let color=prompt("what color do you want?")
document.body.style.background=color
console.log(document.body.lastChild)*/