/*alert("enter the value of a")
let a= prompt("enter the value of a here"," enter the value of a ")
a = Number.parseInt(a)
document.write("the value of a is  " + a)

alert ("you have enter type of " +(typeof a))

let write =confirm(" do you really want to write ")
if(write){document.write(a)}
else{
document.write(" please allow me to write")}

*/
//window object
//dom
//bom

//dom bom 

/*console.log(window)

console.log(document.body)

document.body.style.background="red"

*/
let x =function (e){
let age =prompt("hey What is your age? ")
age =Number.parseInt(age)
while(isNaN(age)) {
        alert("sorry") &&prompt("please enter a valid age" )
}
if(age >= 18){alert ("congratulations you can drive car");
               let tryagain=confirm("do you want to change it")
               
while(tryagain){
        age=prompt("please give a valid age")
if(age<0){alert("please give me a valid age")}        
        if(age >= 18){alert ("congratulations you can drive car");break;}
else{alert ("sorry you can not drive ");
 tryagain=confirm("do you want to try again")}
}
}
else {alert("sorry you can drive car")
        let tryAgain=confirm("please try again")

while(tryAgain){
        age=prompt("please give a valid age")
        if(age >= 18){alert ("congratulations you can drive car");break;}
else{alert ("sorry you can not drive ");
 tryAgain=confirm("do you want to try again")}

}}}
button.addEventListener ('click',x)
let y=function(e){let color = prompt("what color do you want?")
document.body.style.backgroundColor = color}
colors.addEventListener('click',y)